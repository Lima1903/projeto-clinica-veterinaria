
package Classes;


public class Pessoa {
    private String nomeDono;
    private String CPF;

    public String getNomeDono() {
        return nomeDono;
    }

    public void setNomeDono(String nomeDono) {
        this.nomeDono = nomeDono;
    }

    public String getCPF() {
        return CPF;
    }

    public void setCPF(String CPF) {
        this.CPF = CPF;
    }

    public Pessoa(String nomeDono, String CPF) {
        this.nomeDono = nomeDono;
        this.CPF = CPF;
    }
    
    
    
}
