
package Classes;


public class Animal {
    private int Cod;
    private String nomeAnimal;
    private String raca;
    private int anoNascimento;

    public int getCod() {
        return Cod;
    }

    public void setCod(int Cod) {
        this.Cod = Cod;
    }

    public String getNomeAnimal() {
        return nomeAnimal;
    }

    public void setNomeAnimal(String nomeAnimal) {
        this.nomeAnimal = nomeAnimal;
    }

    public String getRaca() {
        return raca;
    }

    public void setRaca(String raca) {
        this.raca = raca;
    }

    public int getAnoNascimento() {
        return anoNascimento;
    }

    public void setAnoNascimento(int anoNascimento) {
        this.anoNascimento = anoNascimento;
    }

    public Animal(int Cod, String nomeAnimal, String raca, int anoNascimento) {
        this.Cod = Cod;
        this.nomeAnimal = nomeAnimal;
        this.raca = raca;
        this.anoNascimento = anoNascimento;
    }
    
    
}
