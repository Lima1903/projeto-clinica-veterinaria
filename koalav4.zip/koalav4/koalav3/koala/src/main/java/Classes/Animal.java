
package Classes;


public class Animal {
    private String Cod;
    private String nomeAnimal;
    private String raca;
    private int anoNascimento;
    private String nomeDono;
    private String CPF;

    public String getNomeDono() {
        return nomeDono;
    }

    public void setNomeDono(String nomeDono) {
        this.nomeDono = nomeDono;
    }

    public String getCPF() {
        return CPF;
    }

    public void setCPF(String CPF) {
        this.CPF = CPF;
    }

    public String getCod() {
        return Cod;
    }

    public void setCod(String Cod) {
        this.Cod = Cod;
    }

    public String getNomeAnimal() {
        return nomeAnimal;
    }

    public void setNomeAnimal(String nomeAnimal) {
        this.nomeAnimal = nomeAnimal;
    }

    public String getRaca() {
        return raca;
    }

    public void setRaca(String raca) {
        this.raca = raca;
    }

    public int getAnoNascimento() {
        return anoNascimento;
    }

    public void setAnoNascimento(int anoNascimento) {
        this.anoNascimento = anoNascimento;
    }

    public Animal(String Cod, String nomeAnimal, String raca, int anoNascimento, String nomeDono, String CPF) {
        this.Cod = Cod;
        this.nomeAnimal = nomeAnimal;
        this.raca = raca;
        this.anoNascimento = anoNascimento;
        this.nomeDono = nomeDono;
        this.CPF = CPF;
    }
    
}
